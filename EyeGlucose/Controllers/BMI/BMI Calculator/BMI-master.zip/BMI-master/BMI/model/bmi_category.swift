//
//  bmi_category.swift
//  BMI
//
//  Created by Ravi Thakur on 16/07/20.
//  Copyright © 2020 billidevelopers. All rights reserved.
//

import UIKit

struct bmi_category {
    let value: Float
    let advice: String
    let color: UIColor
    
}
